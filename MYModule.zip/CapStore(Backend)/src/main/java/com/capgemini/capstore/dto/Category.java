package com.capgemini.capstore.dto;

public enum Category {
	Electronics, Clothing, FootWear, Grocery, Cosmetics,Sports
}
