package com.capgemini.capstore;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.dto.CartDTO;
import com.capgemini.capstore.dto.Customer;
import com.capgemini.capstore.dto.Product;
import com.capgemini.capstore.repo.CartDAO;
import com.capgemini.capstore.repo.CustomerDAO;
import com.capgemini.capstore.repo.ProductDAO;

@RestController
@RequestMapping("hellorest")
public class RestApplication {

	@Autowired
	CartDAO cartDaoRef;
	@Autowired
	CustomerDAO customerDaoRef;
	@Autowired
	ProductDAO productDaoRef;

/*	@RequestMapping(method = RequestMethod.GET)
	public String sayHello() {
		return "Hello World..!! I am From Backend";
	}*/

	@RequestMapping(method = RequestMethod.GET, value = "cartdetails/{id}")
	public ArrayList<Product> list(@PathVariable(name = "id") int id,ModelMap modelMap) {

		List<CartDTO> customerCart = new ArrayList<CartDTO>();
		ArrayList<Product> products = new ArrayList<Product>();

		Customer customer = customerDaoRef.getOne(id);

		customerCart = cartDaoRef.getCartDetailsOfSpecificCustomer(customer);

		for (CartDTO c : customerCart) {
			Product p = c.getProduct();
			p.setProductPrice(c.getProductPrice());
			p.setProductQuantity(c.getQuantity());
			products.add(p);
			System.out.println(c.getProduct().getProductBrand());
		}
				return products;
	}

	@RequestMapping(method = RequestMethod.GET, value = "customerdetails/{id}")
	public Customer getCustomer(@PathVariable(name = "id") int id) {
		Customer customer = customerDaoRef.getOne(id);
		System.out.println(customer.getCustomerEmail());
		return customer;
	}

}
