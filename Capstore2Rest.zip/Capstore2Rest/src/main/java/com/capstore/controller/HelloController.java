package com.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.dto.Offer;
import com.capstore.dto.Promo;
import com.capstore.repo.Dao;



@RestController
@RequestMapping("api/v1/")
public class HelloController {
@Autowired
Dao daoref;
	
/*	@RequestMapping(value="response")
	public Response getResponse(){
		
		Result result = new Result();
		result.setAlpah3_code("IND");
		result.setAlpha2_code("IN");
		result.setName("INDIA");
		
		RestResponse restResponse = new RestResponse();
		
		restResponse.setMessages(new String[]{"More webservices are available at http://www.groupkt.com/post/f2129b88/services."});
		restResponse.setResult(result);
		
		Response response = new Response();
		response.setRestResponse(restResponse);
		
		return response;
	}
*/	
@RequestMapping(method = RequestMethod.POST, value = "response")
public Promo save(@RequestBody Promo pro) {

	return daoref.create(pro);}
@RequestMapping(method = RequestMethod.GET, value = "response1")
public  List<Offer> retrieve() {

	

	return daoref.promo();}

	
	





}

