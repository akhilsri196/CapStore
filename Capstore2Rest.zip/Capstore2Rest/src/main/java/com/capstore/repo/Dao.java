package com.capstore.repo;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capstore.dto.Offer;
import com.capstore.dto.Promo;
import com.capstore.dto.SoftDelete;








@Repository
@Transactional
public class Dao {

	
	
		//provides variable to perform crud operation on jdbc
		@PersistenceContext
		public EntityManager entityManager;
		/*@Override
		public List<Product> list() {
			// TODO Auto-generated method stub
			
			return  query.getResultList();
		}

	*/ // generate coupon
		@Transactional
		public Promo create(Promo pr ) {
			// TODO Auto-generated method stub
			PrintWriter writer;
			
			
			
			/*SoftDelete d= SoftDelete.Deactivated;*/
			
			
			
			/*Coupon coupon=new Coupon();
			coupon.setCode(code);
			coupon.setDiscount(discount);
			coupon.setEnddate(date);*/
			Promo promo=new Promo();
			promo.setDiscountOffered(pr.getDiscountOffered());
			promo.setPromoCode(pr.getPromoCode());
			promo.setPromoValidity(pr.getPromoValidity());
			//promo.setSoftDelete(d);
			
try {
	File file = new File("D:\\eclipse\\module1\\finalproject\\merge\\manasBackend.zip_expanded\\Capstore2Rest\\text\\coupon.txt");
				
	/*FileWriter fileWriter = new FileWriter(file.getAbsoluteFile(),true);	
				fileWriter.write(coupon.getCode());
				fileWriter.write(Double.toString(coupon.getDiscount()));
				fileWriter.write(coupon.getEnddate());
				fileWriter.flush();
				fileWriter.close();*/
				
				
	FileWriter fileWriter = new FileWriter(file.getAbsoluteFile(),true);	
	fileWriter.write(promo.getPromoCode()+"**");
	fileWriter.write(Double.toString(promo.getDiscountOffered())+"**");
	DateFormat df = new SimpleDateFormat("YYY/MM/dd");
	String text = df.format(promo.getPromoValidity());
	fileWriter.write(text+"-----------");
	fileWriter.flush();
	fileWriter.close();				
				
				
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			
			
	
			entityManager.persist(promo);
			return promo;
			
		}

		// generate promo
		public List<Offer>  promo()
		
		{
			
			Query query = entityManager.createQuery(
					"select pr from Offer pr");
			List<Offer> ls=(List<Offer>)query.getResultList();
		
			return ls;
			
			
			
		}
		
		
		/*public List<Return1> return1(int id)
				{
			Query query = entityManager.createQuery(
					"select ret from Return1 ret");
			List<Return1> nl = new ArrayList<Return1>();
			List<Return1> ls=(List<Return1>)query.getResultList();
			for(Return1 r:ls)
			{
				if(r.getCustid()==id)
					nl.add(r);
			}
				
				return nl;}
		*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
}
