package com.capstore.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capstore.dto.Admin;
import com.capstore.dto.Customer;
import com.capstore.dto.Merchant;
import com.capstore.dto.Product;


@Repository
public class MerchantRepoImpl implements MerchantRepo {

	@PersistenceContext
	EntityManager em;
	
	@Override
	public List<Merchant> findAll() {
		Query query = em.createQuery("select merchant from Merchant merchant");

		List<Merchant> ls = (List<Merchant>) query.getResultList();
		
		
		return ls;
		
		
	}

	@Override
	public Merchant findOne(int id) {
		// TODO Auto-generated method stub
		em.find(Merchant.class, id);
		return em.find(Merchant.class, id);
	}

	
	@Override
	public List<Customer> findAllCustomer() {
		Query query = em.createQuery("select customer from Customer customer");

		List<Customer> lc = (List<Customer>) query.getResultList();
		
		
		return lc;
	}

	@Override
	public Customer findCustomer(int id) {
		
		return em.find(Customer.class, id);
	}

	@Override
	public Admin findAdmin(int id) {
		//em.find(Admin.class, id);
		return em.find(Admin.class, id);
	}

	@Override
	public List<Product> findMerchantProducts(Merchant mer) {
		Query query = em.createQuery("select p from Product p where merchant=:merchant");
		query.setParameter("merchant", mer);
		return query.getResultList();
	}

	
	

}
