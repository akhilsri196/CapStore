package com.capstore.repo;

import java.util.List;

import com.capstore.dto.Customer;
import com.capstore.dto.Merchant;

public interface RepoRest {
	public List<Merchant> findAll();
	public List<Customer> findAllCustomer();
	public void delete(String[] id);
	Merchant addMerchant(Merchant merchant);
	void deleteProduct(String[] id);
	public boolean deleteProductFromParticularMerchant(int MerchantId);
}
