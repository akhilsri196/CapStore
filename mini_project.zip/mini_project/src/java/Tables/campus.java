package Tables;
import javax.persistence.*;
@Entity
public class campus 
{
 @Id
 @GeneratedValue
 private int id;
 private String hostel;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getHostel() {
        return hostel;
    }

    public void setHostel(String hostel) {
        this.hostel = hostel;
        
    }
}