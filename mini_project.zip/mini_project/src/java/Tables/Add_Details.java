package Tables;
import javax.persistence.*;
@Entity
public class Add_Details 
{
 @Id
 @GeneratedValue
 private int ID;
 private String Category;
 private String Brand;
 private int Price;
 private String Description;
 private String Photo;
 private String Seller_Num;

    public String getBrand() {
        return Brand;
    }

    public void setBrand(String Brand) {
        this.Brand = Brand;
    }

    public String getSeller_Num() {
        return Seller_Num;
    }

    public void setSeller_Num(String Seller_Num) {
        this.Seller_Num = Seller_Num;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String Category) {
        this.Category = Category;
    }

    public int getPrice() {
        return Price;
    }

    public void setPrice(int Price) {
        this.Price = Price;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public String getPhoto() {
        return Photo;
    }

    public void setPhoto(String Photo) {
        this.Photo = Photo;
    }
 
}
