
package jdbc;
import java.sql.*;
public class dao 
{
public static void main(String[] args)
{
  select();  
}
public static void select()
{
    try{
   Connection c=jdbc.getCon();
   Statement s=c.createStatement();
   ResultSet rs = s.executeQuery("Select * from Student");
         while(rs.next())
         {
             System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3));
         }
}catch(Exception e)
{System.out.println("Error");   }
}
    
}
