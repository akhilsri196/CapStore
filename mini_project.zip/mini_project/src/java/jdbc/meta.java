package jdbc;
import java.sql.*;
public class meta
{
    public static void main(String[] args) {
        
    try
    {
       Connection c=jdbc.getCon();
       Statement s=c.createStatement();
       ResultSet rs=s.executeQuery("Select * from student where name='akhilesh'");
       ResultSetMetaData rsmd=rs.getMetaData();
       System.out.println(rsmd.getColumnCount());
       System.out.println(""+rsmd.getColumnTypeName(1));
    } 
    catch(Exception e)
    {
       System.out.println("Error");
    }
    }
}