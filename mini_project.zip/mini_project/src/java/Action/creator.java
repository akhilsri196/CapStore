package Action;
//import Tables.User_Details;
//import Tables.campus;
import Tables.Add_Details;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class creator {
    public static void main(String[] args) {
        Configuration cfg=new Configuration() ;
        
        //cfg.addAnnotatedClass(User_Details.class);
        //cfg.addAnnotatedClass(campus.class);
        cfg.addAnnotatedClass(Add_Details.class);
        cfg.configure();
        SchemaExport se=new SchemaExport(cfg);
        se.create(true,true);
        System.out.println("TABLE CREATED !!");
    }
    
}
