package Main;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import jdbc.jdbc;
import Tables.*;
public class Authentication extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException 
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String u_id=request.getParameter("id");
        String u_pwd=request.getParameter("pwd"); 
        RequestDispatcher rd;
        RequestDispatcher rd1;
        
       try
        {
           Connection c=jdbc.getCon();
           Statement s=c.createStatement();
   
           String q="Select * from User_Details where Mail='"+u_id+"' and Password='"+u_pwd+"'";
           ResultSet rs = jdbc.selectData(q);
           if(rs.next())
             {                
                 HttpSession vsn = request.getSession();
                 vsn.setAttribute("vid",u_id);
                 vsn.setAttribute("naam",rs.getString(3));
                 rd1=request.getRequestDispatcher("newjsp.jsp");
                 rd1.forward(request,response);
             } 
           else
             { 
               request.setAttribute("Error_Msg1","    ..Id Password Mismatched.."); 
            
               rd=request.getRequestDispatcher("login.jsp");
               rd.include(request,response);
             }
             
           
        }
        
        catch(Exception e)
        {
            System.out.println(e);
        }   
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    
    public String getServletInfo() {
        return "Short description";
    }

}
