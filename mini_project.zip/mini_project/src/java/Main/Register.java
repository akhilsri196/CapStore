package Main;
import org.hibernate.Session;
import javax.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import org.hibernate.Transaction;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Tables.*;


public class Register extends HttpServlet {
protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
{
    RequestDispatcher rd;
   PrintWriter out=response.getWriter();
   try{
          String s1=request.getParameter("name");
          String s2=request.getParameter("num");
          String s4=request.getParameter("id");
          String s5=request.getParameter("pwd");
          String s6=request.getParameter("cpwd");
              Session s=hiber.daohib.getSession();
              Transaction t=s.beginTransaction();
              User_Details v1=new User_Details();
              if(s5.equals(s6))
             { 
              v1.setNumber(s2);
              v1.setName(s1);
              v1.setPassword(s5);
              v1.setMail(s4);
              s.save(v1);
              t.commit();
              request.setAttribute("msg","...Succesfully Signed Up...");
              }
              else
              {
               request.setAttribute("msg"," ..Your password is Mismatched..");
              }
               rd=request.getRequestDispatcher("register.jsp");
               rd.forward(request,response);
              
             }
   catch(Exception e)
   {
      out.println("exception"+e);
   }
  }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
