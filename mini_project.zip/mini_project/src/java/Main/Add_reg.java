package Main;
import org.hibernate.Session;
import javax.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import org.hibernate.Transaction;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Tables.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.http.HttpSession;
import jdbc.jdbc;


public class Add_reg extends HttpServlet {
protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
{
    RequestDispatcher rd;
   PrintWriter out=response.getWriter();
   try{
        String s1=request.getParameter("category");
           String s2=request.getParameter("sub");
         int i1= Integer.parseInt(request.getParameter("Price"));
          String s4=request.getParameter("Desc");
         String s5=request.getParameter("file");
        String nm="";
      HttpSession vsn = request.getSession(false);
                 String id=(String)vsn.getAttribute("vid");
                 out.print(id);
        ResultSet rs_count;
              
  String query ="SELECT number FROM user_details where mail='"+id+"'";
  
  
       Connection c=jdbc.getCon();
       Statement stmt=c.createStatement();
       rs_count=stmt.executeQuery(query);
       while(rs_count.next())
       {
           nm=rs_count.getString(1);
       }
              Session s=hiber.daohib.getSession();
              Transaction t=s.beginTransaction();
              Add_Details v1=new Add_Details(); 
              v1.setCategory(s1);
              v1.setPrice(i1);
              v1.setDescription(s4);
              v1.setBrand(s2);
              v1.setSeller_Num(nm);
              v1.setPhoto(s5);
              s.save(v1);
              t.commit();
              request.setAttribute("add","...Ad Succesfully Posted...");
              rd=request.getRequestDispatcher("post-ad.jsp");
              rd.forward(request,response);
              
             }
   catch(Exception e)
   {
      out.println("exception"+e);
   }
  }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
