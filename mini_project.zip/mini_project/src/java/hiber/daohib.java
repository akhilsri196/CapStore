package hiber;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import Tables.User_Details;
public class daohib {
    private static SessionFactory sessionFactory;
    static {
         Configuration cfg = new Configuration();
         cfg.addAnnotatedClass(User_Details.class);
         cfg.configure();
         sessionFactory = cfg.buildSessionFactory();
    }
    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
    public static Session getSession() {
        return sessionFactory.openSession();
    }
}
