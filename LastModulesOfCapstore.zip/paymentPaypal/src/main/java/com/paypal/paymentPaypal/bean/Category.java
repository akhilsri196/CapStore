package com.paypal.paymentPaypal.bean;

public enum Category {
	Electronics, Clothing, FootWear, Grocery, Cosmetics,Sports
}
