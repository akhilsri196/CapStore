package com.paypal.paymentPaypal.setup;

public class PayPalConfig {

	private String authToken;
	private String posturl;
	private String buisness;
	private String returnurl;
	public String getAuthToken() {
		return authToken;
	}
	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}
	public String getPosturl() {
		return posturl;
	}
	public void setPosturl(String posturl) {
		this.posturl = posturl;
	}
	public String getBuisness() {
		return buisness;
	}
	public void setBuisness(String buisness) {
		this.buisness = buisness;
	}
	public String getReturnurl() {
		return returnurl;
	}
	public void setReturnurl(String returnurl) {
		this.returnurl = returnurl;
	}
	
	
	
	
	
	
}
