package PersonDetails;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.openqa.selenium.Alert;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pom.structure.Browser;
import pom.structure.EducationalDetailsPageFactory;
import pom.structure.PersonDetailsPageFactory;

public class StepDefinitions {

	private PersonDetailsPageFactory person;
	private EducationalDetailsPageFactory education;

	@Before
	public void setup() {
		Browser browser = new Browser();
		person = new PersonDetailsPageFactory(browser);
		education = new EducationalDetailsPageFactory(browser);
	}

	@Given("^User is on PersonalDetails\\.html page$")
	public void user_is_on_PersonalDetails_html_page() throws Throwable {
		person.goTo();
	}

	@Then("^check the title of the registraion page$")
	public void check_the_title_of_the_registraion_page() throws Throwable {
		// education.setCheckBoxButton("Java");
		assertTrue(person.isAt());
	}

	@When("^user leaves FirstName blank$")
	public void user_leaves_FirstName_blank() throws Throwable {
		person.setFname("");
	}

	@When("^clicks the Next button$")
	public void clicks_the_Next_button() throws Throwable {
		person.setNextbutton();
	}

	@Then("^display firstname alert msg$")
	public void display_firstname_alert_msg() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill the First Name", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000); // to wait atleast something is visible on screen
	}

	@When("^user leaves LastName blank$")
	public void user_leaves_LastName_blank() throws Throwable {
		person.setFname("Priya");

		person.setLname("");
	}

	@Then("^display lastname alert msg$")
	public void display_lastname_alert_msg() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill the Last Name", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves Email blank$")
	public void user_leaves_Email_blank() throws Throwable {
		person.setFname("Priya");
		Thread.sleep(1000);
		person.setLname("Singh");
		Thread.sleep(1000);
		person.setEmail("");
	}

	@Then("^display email alert msg$")
	public void display_email_alert_msg() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill the Email", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user enters all data$")
	public void user_enters_all_data() throws Throwable {
		person.setFname("Priya");

		person.setLname("Singh");

		person.setLine1("Talwade");

		person.setLine2("Dhanlakshmi");

		person.setCity("Pune");

		person.setMobile("8790245678");
		person.setState("Maharashtra");

	}

	@When("^user enters incorrect email format$")
	public void user_enters_incorrect_email_format() throws Throwable {
		person.setEmail("p@com");

	}

	@Then("^display wrong email format alert msg$")
	public void display_wrong_email_format_alert_msg() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Please enter valid Email Id.", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves MobileNo blank$")
	public void user_leaves_MobileNo_blank() throws Throwable {
		person.setFname("Priya");
		Thread.sleep(1000);
		person.setLname("Singh");
		Thread.sleep(1000);
		person.setEmail("priya16@gmail.com");
		Thread.sleep(1000);
		person.setMobile("");
	}

	@Then("^display mobileNo alert msg$")
	public void display_mobileNo_alert_msg() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill the Contact No.", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user enters incorrect mobileNo format$")
	public void user_enters_incorrect_mobileNo_format() throws Throwable {
		person.setFname("Priya");
		Thread.sleep(1000);
		person.setLname("Singh");
		Thread.sleep(1000);
		person.setEmail("priya16@gmail.com");
		Thread.sleep(1000);
		person.setMobile("876754");
	}

	@Then("^display wrong mobileNo alert msg$")
	public void display_wrong_mobileNo_alert_msg() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Please enter valid Contact no.", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}


	



	@When("^user leaves City blank$")
	public void user_leaves_City_blank() throws Throwable {
		person.setFname("Priya");
		person.setLname("Singh");
		person.setLine1("Talwade");
		person.setLine2("Chowk");

		person.setEmail("priya16@gmail.com");
		person.setMobile("8790245678");

	}

	@Then("^display City alert msg$")
	public void display_City_alert_msg() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Please select city", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves State blank$")
	public void user_leaves_State_blank() throws Throwable {
		person.setFname("Priya");
		person.setLname("Singh");
		person.setLine1("Talwade");
		person.setLine2("Chowk");
		person.setCity("Pune");
		person.setEmail("priya16@gmail.com");
		person.setMobile("8790245678");

	}

	@Then("^display State alert msg$")
	public void display_State_alert_msg() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Please select state", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user enters all valid Registration data$")
	public void user_enters_all_valid_Registration_data() throws Throwable {
		person.setFname("Priya");
		person.setLname("Singh");
		person.setLine1("Talwade");
		person.setLine2("Chowk");
		person.setCity("Pune");
		person.setEmail("priya16@gmail.com");
		person.setMobile("8790245678");

		person.setState("Maharashtra");

	}

	@Then("^display success alert msg$")
	public void display_Success_alert_msg() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Personal details are validated and accepted successfully.", alert.getText());
		System.out.println(alert.getText());
		person.getBrowser().driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@Then("^navigate to educationDetails\\.html page$")
	public void navigate_to_educationDetails_html_page() throws Throwable {
		education.goTo();
		assertTrue(education.isAt());
	}

	@Given("^User is on educationDetails\\.html page$")
	public void user_is_on_educationDetails_html_page() throws Throwable {
		education.goTo();
	}

	@Then("^check the title of the education page$")
	public void check_the_title_of_the_education_page() throws Throwable {
		assertTrue(education.isAt());
	}
	
	@When("^user leaves Line1 blank$")
	public void user_leaves_Line_blank() throws Throwable {
		person.setFname("Priya");
		Thread.sleep(1000);
		person.setLname("Singh");
		Thread.sleep(1000);
		person.setEmail("priya16@gmail.com");
		Thread.sleep(1000);
		person.setMobile("8790245678");
		Thread.sleep(1000);
	}

	@Then("^display Line1 alert msg$")
	public void display_Line1_alert_msg() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill the address line 1", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}
	
	@When("^user leaves Line2 blank$")
	public void user_leaves_Line2_blank() throws Throwable {
		person.setFname("Priya");
		Thread.sleep(1000);
		person.setLname("Singh");
		Thread.sleep(1000);
		person.setEmail("priya16@gmail.com");
		Thread.sleep(1000);
		person.setMobile("8790245678");
		person.setLine1("Talwade");
		Thread.sleep(1000);
	}
	
	@Then("^display Line2 alert msg$")
	public void display_Line_alert_msg() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill the address line 2", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	
	
	
	
	@When("^user leaves Graduation blank and clicks the button$")
	public void user_leaves_Graduation_blank_and_clicks_the_button() throws Throwable {
		education.setRegisterButton();
	}

	@Then("^display Graduation alert msg$")
	public void display_Graduation_alert_msg() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Please Select Graduation", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves Percentage blank and clicks the button$")
	public void user_leaves_Percentage_blank_and_clicks_the_button() throws Throwable {
		education.setGraduation("B.Tech.");
		
		education.setRegisterButton();
	}

	@Then("^display Percentage alert msg$")
	public void display_Percentage_alert_msg() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill Percentage detail", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves PassingYear blank and clicks the button$")
	public void user_leaves_PassingYear_blank_and_clicks_the_button() throws Throwable {
		education.setGraduation("B.Tech.");
		education.setPercent("88");
		
		education.setRegisterButton();
	}

	@Then("^display PassingYear alert msg$")
	public void display_PassingYear_alert_msg() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill Passing Year", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves ProjectName blank and clicks the button$")
	public void user_leaves_ProjectName_blank_and_clicks_the_button() throws Throwable {
		education.setGraduation("B.Tech.");
		education.setPercent("88");
		education.setPassingyr("2019");
	
		education.setRegisterButton();
	}

	@Then("^display ProjectName alert msg$")
	public void display_ProjectName_alert_msg() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill Project Name", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves Technology blank and clicks the button$")
	public void user_leaves_Technology_blank_and_clicks_the_button() throws Throwable {
		education.setGraduation("B.Tech.");
		education.setPercent("88");
		education.setPassingyr("2019");
		education.setProjectnm("Capstore project");
		
		education.setRegisterButton();
	}

	@Then("^display Technology alert msg$")
	public void display_Technology_alert_msg() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Please Select Technologies Used", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves OtherTechnology blank and clicks the button$")
	public void user_leaves_OtherTechnology_blank_and_clicks_the_button() throws Throwable {
		education.setGraduation("B.Tech.");
		education.setPercent("88");
		education.setPassingyr("2019");
		education.setProjectnm("Capstore project");
		education.setCheckBoxButton("Java");
		
		education.setRegisterButton();
	}

	@Then("^display OtherTechnology alert msg$")
	public void display_OtherTechnology_alert_msg() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill other Technologies Used", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user enters all valid education details and clicks the button$")
	public void user_enters_all_valid_education_details_and_clicks_the_button() throws Throwable {
		education.setGraduation("B.Tech.");
		education.setPercent("88");
		education.setPassingyr("2019");
		education.setProjectnm("Capstore project");
		education.setCheckBoxButton("Java");
		education.setTech("C");
		education.setRegisterButton();
	}

	@Then("^check the alert message$")
	public void check_the_alert_message() throws Throwable {
		Alert alert = person.getBrowser().driver.switchTo().alert();
		assertEquals("Your Registration Has succesfully done Plz check you registerd email for account activation link !!!", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@After
	public void exit() {
		 person.getBrowser().close();
	}
}
