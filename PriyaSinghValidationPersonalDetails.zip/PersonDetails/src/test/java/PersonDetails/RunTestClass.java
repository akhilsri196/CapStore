package PersonDetails;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty" }) //I have my feature file inside a folder named as conferenceRegister
public class RunTestClass {
}
