package com.capstore.dto;

public enum Category {
	Men,Women,Kids,Electronics
	}
