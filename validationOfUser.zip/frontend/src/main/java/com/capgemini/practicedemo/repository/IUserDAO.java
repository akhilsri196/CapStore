package com.capgemini.practicedemo.repository;

import java.util.*;

public interface IUserDAO 
{
    public String validateUser(String email,String password); 

}