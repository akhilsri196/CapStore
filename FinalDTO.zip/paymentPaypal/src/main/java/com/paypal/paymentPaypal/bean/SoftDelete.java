package com.paypal.paymentPaypal.bean;

public enum SoftDelete {
	Activated, Deactivated
}
