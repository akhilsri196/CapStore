
package com.capgemini.capstore;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.dto.Customer;
import com.capgemini.capstore.dto.Merchant;
import com.capgemini.capstore.dto.MerchantFeedback;
import com.capgemini.capstore.dto.Product;
import com.capgemini.capstore.dto.ProductFeedback;
import com.capgemini.capstore.repo.MerchantRepo;
import com.capgemini.capstore.repo.RepoRest;



@RestController
@RequestMapping("restController")
public class AdminRestController2 {
	@Autowired
	RepoRest daoRef;
	@Autowired
	MerchantRepo merchantRef;

	@RequestMapping(method = RequestMethod.GET, value = "/merchantList")
	public List<Merchant> show() {
		System.out.println("in merchant");
		return daoRef.findAll();

	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/productList/{id}")
	public List<Product> showProduct(@PathVariable("id") String id) {
		System.out.println("in product");
		return daoRef.findAllProduct(Integer.parseInt(id));

	}


	@RequestMapping(method = RequestMethod.GET, value = "/customerList")
	public List<Customer> showCustomers() {
		System.out.println("in customer");
		return daoRef.findAllCustomer();
	}

	@RequestMapping(method = RequestMethod.POST, value = "/delete")
	public void delete(@RequestParam("id") String ids) {
		String str[] = ids.split(",");
		System.out.println("hello");
	for(String s:str)
	{
		int merchantid=Integer.parseInt(s);
		daoRef.deleteProductFromParticularMerchant(merchantid);
	}
		daoRef.delete(str);
	}
	

	@RequestMapping(method = RequestMethod.POST, value = "/deleteProduct")
	public void deleteProduct(@RequestParam("id") String ids) {
		String str[] = ids.split(",");
		System.out.println(ids);
		for(String s:str)
		{
			System.out.println(s+"in");
			int productid=Integer.parseInt(s);
			daoRef.deleteEntryOfParticularProductfromWishlist(productid);
			daoRef.deleteEntryOfParticularProductfromOffers(productid);
			daoRef.deleteEntryOfParticularProductfromCart(productid);
			daoRef.deleteEntryOfParticularProductfromProductFeedback(productid);
			daoRef.deleteProductFromParticularMerchant(productid);
		}
		daoRef.deleteProduct(str);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/addProductFeedback")
	public void Feedback(@RequestBody ProductFeedback productfeedback,ModelMap map,@RequestParam("id") String id) {
		// map.put("merchant","merchant ");
		System.out.println("hello world");
		System.out.println(productfeedback.getProductFeedback());
		System.out.println("Inside AdminRestController"+ productfeedback.getProductFeedback());
		System.out.println("hello world" + id);
		//PRODUCT ID TO BE RECEIVED FROM SESSION
		daoRef.addProductFeedback(productfeedback,id);
	}

	/* For adding merchant */

	@RequestMapping(method = RequestMethod.POST, value = "/addMerchant")
	public void list1(@RequestBody Merchant merchant) {
		// map.put("merchant","merchant ");
		System.out.println("hello world");
		System.out.println(merchant.getMerchantName());
		System.out.println("Inside AdminRestController"+ merchant.getMerchantId());
		daoRef.addMerchant(merchant);
		
	}
	
	/*for adding product*/

	@RequestMapping(method = RequestMethod.POST, value = "/addProd")
	public void AddProduct(@RequestBody Product product,@RequestParam("id") String merchantid) {
		// map.put("merchant","merchant ");
		Merchant merchant=merchantRef.findOne(Integer.parseInt(merchantid));
		product.setMerchant(merchant);
		System.out.println("hello world");
		System.out.println(product.getProductModel());
		System.out.println("hello world");
		/*Merchant merchant=new Merchant();
		product.setMerchant(merchant);*/
		daoRef.addProduct(product,Integer.parseInt(merchantid));
		// return "addMerchantSuccess";
	}
	
	

	@RequestMapping(method = RequestMethod.POST, value = "/addMerchantFeedback")
	public void Feedback(@RequestBody MerchantFeedback merchantFeedback,ModelMap map,@RequestParam("id") String id) {
		// map.put("merchant","merchant ");
		System.out.println("hello world");
		System.out.println(merchantFeedback.getMerchantFeedback());
		System.out.println("hello world" + id);
		//MERCHANT ID TO BE RECEIVED FROM SESSION
		daoRef.addFeedback(merchantFeedback,id);
	}
	

}
