package com.capgemini.capstore.repo;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.dto.Customer;
import com.capgemini.capstore.dto.Order;

@Repository
public interface OrdersRepo extends JpaRepository<Order, Integer>{

	@Query("SELECT m FROM Order m WHERE m.customer =:customer")
	List<Order> getOrdersByCustomer(@Param("customer")Customer customer);

}
