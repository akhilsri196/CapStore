package com.capgemini.capstore.services;

import java.util.List;

import com.capgemini.capstore.dto.CartDTO;
import com.capgemini.capstore.dto.Customer;
import com.capgemini.capstore.dto.Order;
import com.capgemini.capstore.dto.Wishlist;
import com.capgemini.capstore.exceptions.InvalidInputException;
import com.capgemini.capstore.exceptions.ProductUnavailableException;


public interface CustomerServices {

	public boolean addProductToWishlist(int customerId,int productId) throws InvalidInputException;

	public void removeProductFromWishlist(int itemId) throws InvalidInputException;

	public List<Wishlist> getAllWishlist(int customerId) throws InvalidInputException;

	public List<CartDTO> getAllProductsFromCart(int customerId) throws InvalidInputException;

	CartDTO addProductToNewCart(int customerId,int merchantID) throws ProductUnavailableException;

	CartDTO updateCart(int customerId,int productId, int quantity) throws ProductUnavailableException;

	void removeProductFromCart(int cartId);//once removed from cart, update stock & quantity in product

	public Customer getCustomer(int customerId);

	public Customer updateCustomer(Customer customer);

	public void modifyQuantity(String cartId, int update);

	public void moveToCart(int parseInt, int parseInt2);

	public String getEmail(int id);
	/*
	 * double applyDiscount(int productId);
	 * 
	 * double applyCoupon(int cartId);
	 */

	public List<Order> getMyOrders(String userid);

	public void saveOrder(int id);
}
