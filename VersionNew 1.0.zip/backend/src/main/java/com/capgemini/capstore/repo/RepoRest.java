package com.capgemini.capstore.repo;

import java.util.List;

import com.capgemini.capstore.dto.Customer;
import com.capgemini.capstore.dto.Merchant;
import com.capgemini.capstore.dto.MerchantFeedback;
import com.capgemini.capstore.dto.Product;
import com.capgemini.capstore.dto.ProductFeedback;



public interface RepoRest {
	public List<Merchant> findAll();
	public List<Customer> findAllCustomer();
	public void delete(String[] id);
	Merchant addMerchant(Merchant merchant);
	void deleteProduct(String[] id);
	public boolean deleteProductFromParticularMerchant(int MerchantId);
	public List<Product> findAllProduct(int MerchantId);
	public Product addProduct(Product product, int parseInt);
	public MerchantFeedback addFeedback(MerchantFeedback merchantFeedback, String id);
	public ProductFeedback addProductFeedback(ProductFeedback productfeedback, String id);
	public boolean deleteEntryOfParticularProductfromWishlist(int productid);
	public boolean deleteEntryOfParticularProductfromOffers(int productid);
	public boolean deleteEntryOfParticularProductfromCart(int productid);
	public boolean deleteEntryOfParticularProductfromProductFeedback(int productid);
}
