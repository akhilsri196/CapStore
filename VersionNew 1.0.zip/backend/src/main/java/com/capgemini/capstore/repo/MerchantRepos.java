package com.capgemini.capstore.repo;



import java.util.List;

import com.capgemini.capstore.dto.Admin;
import com.capgemini.capstore.dto.Customer;
import com.capgemini.capstore.dto.Merchant;
import com.capgemini.capstore.dto.Product;




public interface MerchantRepos{
 public List<Merchant> findAll();
 public Merchant findOne(int id);
 public List<Customer> findAllCustomer();
 public Customer findCustomer(int id);
 public Admin findAdmin(int id);
 public  List<Product> findMerchantProducts(Merchant mer);
 

}
