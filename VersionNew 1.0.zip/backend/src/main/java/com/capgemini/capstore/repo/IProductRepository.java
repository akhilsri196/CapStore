package com.capgemini.capstore.repo;

import java.util.List;

import com.capgemini.capstore.dto.Product;



public interface IProductRepository {

	
	public List<Product> getProduct();
	public List<Product> sortPriceLowToHigh();
	public List<Product> sortPriceHighToLow();
	public List<Product> getSearch(String search);	
	public Product single(int idd);
}
