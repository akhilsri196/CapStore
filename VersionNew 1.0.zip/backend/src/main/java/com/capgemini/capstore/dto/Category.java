package com.capgemini.capstore.dto;

public enum Category {
	Mens,Womens,Kids,Electronics
}
