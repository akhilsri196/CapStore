package com.paypal.paymentPaypal.bean;

public enum Category {
	Mens,Womens,Kids,Electronics
}
