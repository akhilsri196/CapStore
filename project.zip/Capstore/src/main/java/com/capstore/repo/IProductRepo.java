package com.capstore.repo;

import java.util.List;

import com.capstore.bean.Product;

public interface IProductRepo {

	public List<Product> getProduct();
	
}
