package com.capstore.repo;

import java.util.List;

import com.capstore.bean.Product;

public class ProductRepo implements IProductRepo {

	@Override
	public List<Product> getProduct() {
		// TODO Auto-generated method stub
		return null;
	}

}
