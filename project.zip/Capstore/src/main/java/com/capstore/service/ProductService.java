package com.capstore.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capstore.bean.Product;

@Service
public class ProductService implements IProductService{

	@Override
	public List<Product> getProduct() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
