package com.capstore.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.capstore.dto.Customer;
import com.capstore.dto.Merchant;
import com.capstore.dto.MerchantFeedback;
import com.capstore.dto.Product;
import com.capstore.dto.ProductFeedback;



@Repository
@Transactional
public class RepoRestImpl implements RepoRest {
@PersistenceContext	
private EntityManager entityManager;
	@Override
	public List<Merchant> findAll() {
		
		Query query = entityManager.createQuery("select merchant from Merchant merchant");
		List<Merchant> mer = query.getResultList();
		for(Merchant merch:mer)
			System.out.println(merch.getMerchantId());
		return query.getResultList();
	}
	@Override
	public List<Customer> findAllCustomer() {
		Query query = entityManager.createQuery("select customer from Customer customer");
		return query.getResultList();
	}
	@Override
	public void delete(String[] id) {
		try {
			for(String sID : id){
			Merchant merchant = entityManager.find(Merchant.class, Integer.parseInt(sID));
			entityManager.remove(merchant);
		}
	} catch (RuntimeException e) {
	
	throw e;
	} finally {
	entityManager.close();
	}
		
	}
	

	@Override
	public void deleteProduct(String[] id) {
		System.out.println("Inside DAO CLass");
		try {
			for(String sID : id){
			Product product = entityManager.find(Product.class, Integer.parseInt(sID));
			entityManager.remove(product);
		}
	} catch (RuntimeException e) {
	
	throw e;
	} finally {
	entityManager.close();
	}
		
	}
	
	public List<Product> findAllProduct() {
		int MerchantId=2001;
	 Merchant merchant=	entityManager.find(Merchant.class, MerchantId);
		Query query = entityManager.createQuery("select product from Product product where merchant=:merchant");
		query.setParameter("merchant", merchant);
		List<Product> product = query.getResultList();
		for(Product prod:product)
			System.out.println(prod.getProductId());
		return query.getResultList();
	}

	@Override
	public Merchant addMerchant(Merchant merchant) {
		System.out.println(merchant.getMerchantAddress()+merchant.getMerchantEmail()+merchant.getMerchantId());
/*		Merchant merchu = new Merchant();
		merchu.setMerchantAddress("asd");
		merchu.setMerchantEmail("sdfs");
		merchu.setMerchantMobileNumber("wwqe");
		merchu.setMerchantStoreName("asdasdd");
		merchu.setMerchantName("sdfsd");*/
		//merchu.setMerchantId(12012);
		entityManager.persist(merchant);
		
		return merchant;
	}
	
	public Product addProduct(Product product) {
		entityManager.persist(product);
		return product;
	}
	

	public ProductFeedback addProductFeedback(ProductFeedback productFeedback,String id) {
		//Product prod = new Product(2);
		Product prod = entityManager.find(Product.class, Integer.parseInt(id));
		productFeedback.setProduct(prod);
		productFeedback.setRating(4);
		


		entityManager.persist(productFeedback);
		return productFeedback;
	}
	
	
	public MerchantFeedback addFeedback(MerchantFeedback merchantFeedback, String id) {
		System.out.println("Inside DAO class of merchant feedback");
		Merchant merch = entityManager.find(Merchant.class,  Integer.parseInt(id));
		merchantFeedback.setMerchant(merch);
		merchantFeedback.setRating(3);
		entityManager.persist(merchantFeedback);
		System.out.println("Data persisted");
		return merchantFeedback;
		
		// TODO Auto-generated method stub
		
	}

	


}
