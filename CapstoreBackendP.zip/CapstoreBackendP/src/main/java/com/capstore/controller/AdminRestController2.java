
package com.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.dto.Customer;

import com.capstore.dto.Merchant;
import com.capstore.dto.MerchantFeedback;
import com.capstore.dto.Product;
import com.capstore.dto.ProductFeedback;
import com.capstore.repo.RepoRestImpl;

@RestController
@RequestMapping("restController")
public class AdminRestController2 {
	@Autowired
	RepoRestImpl daoRef;

	@RequestMapping(method = RequestMethod.GET, value = "/merchantList")
	public List<Merchant> show() {
		System.out.println("in merchant");
		return daoRef.findAll();

	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/productList")
	public List<Product> showProduct() {
		System.out.println("in product");
		return daoRef.findAllProduct();

	}


	@RequestMapping(method = RequestMethod.GET, value = "/customerList")
	public List<Customer> showCustomers() {
		System.out.println("in customer");
		return daoRef.findAllCustomer();
	}

	@RequestMapping(method = RequestMethod.POST, value = "/delete")
	public void delete(@RequestParam("id") String ids) {
		String str[] = ids.split(",");
		System.out.println("hello");
		daoRef.delete(str);
	}
	

	@RequestMapping(method = RequestMethod.POST, value = "/deleteProduct")
	public void deleteProduct(@RequestParam("id") String ids) {
		String str[] = ids.split(",");
		System.out.println("hello");
		
		daoRef.deleteProduct(str);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/addProductFeedback")
	public void Feedback(@RequestBody ProductFeedback productfeedback,ModelMap map,@RequestParam("id") String id) {
		// map.put("merchant","merchant ");
		System.out.println("hello world");
		System.out.println(productfeedback.getProductFeedback());
		System.out.println("Inside AdminRestController"+ productfeedback.getProductFeedback());
		System.out.println("hello world" + id);
		//PRODUCT ID TO BE RECEIVED FROM SESSION
		daoRef.addProductFeedback(productfeedback,id);
	}

	/* For adding merchant */

	@RequestMapping(method = RequestMethod.POST, value = "/addMerchant")
	public void list1(@RequestBody Merchant merchant) {
		// map.put("merchant","merchant ");
		System.out.println("hello world");
		System.out.println(merchant.getMerchantName());
		System.out.println("Inside AdminRestController"+ merchant.getMerchantId());
		daoRef.addMerchant(merchant);
		
	}
	
	/*for adding product*/

	@RequestMapping(method = RequestMethod.POST, value = "/addProd")
	public void AddProduct(@RequestBody Product product) {
		// map.put("merchant","merchant ");
		System.out.println("hello world");
		System.out.println(product.getProductModel());
		System.out.println("hello world");
		Merchant merchant=new Merchant(1);
		product.setMerchant(merchant);
		daoRef.addProduct(product);
		// return "addMerchantSuccess";
	}
	
	

	@RequestMapping(method = RequestMethod.POST, value = "/addMerchantFeedback")
	public void Feedback(@RequestBody MerchantFeedback merchantFeedback,ModelMap map,@RequestParam("id") String id) {
		// map.put("merchant","merchant ");
		System.out.println("hello world");
		System.out.println(merchantFeedback.getMerchantFeedback());
		System.out.println("hello world" + id);
		//MERCHANT ID TO BE RECEIVED FROM SESSION
		daoRef.addFeedback(merchantFeedback,id);
	}
	

}
