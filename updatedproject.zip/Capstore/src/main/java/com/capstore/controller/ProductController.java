
  package com.capstore.controller;
  
  import org.springframework.stereotype.Controller; import
  org.springframework.web.bind.annotation.RequestMapping; import
  org.springframework.web.bind.annotation.RequestMethod;
  
  @Controller
  public class ProductController {
  
  @RequestMapping(method=RequestMethod.GET,value="admin") 
  public String index() {
	  
	  
	  
  return "admin";
  }
  @RequestMapping(method=RequestMethod.GET,value="/merchantdetails") 
  public String merchant() {
  return "merchantDetails";
  } 
  }
 
