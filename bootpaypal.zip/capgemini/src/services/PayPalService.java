package services;

import abcd.PayPalConfig;

public interface PayPalService {

	public PayPalConfig getPayPalConfig();
}
