package abcd;

import java.util.List;

import services.PayPalService;

@Controller
@RequestMapping("demo")
public class CartController {

	@Autowired
	private PayPalService payPalService;
	
	
	@RequestMapping(method=RequestMethod.GET)
	public String index(ModelMap modelMap)
	{
		List<Product> products=new ArrayList<Product>();
		products.add(new Product("p01","name1",2,3));
		products.add(new Product("p02","name2",4,2));
		products.add(new Product("p03","name3",5,4));
		modelMap.put("products",products);
		modelMap.put("payPalConfig",payPalService.getPayPalConfig());
		return "cart/index";
	}
	@RequestMapping(value="success",method=RequestMethod.GET)
	public String success(HttpServletRequest request)
	{
		PayPalSucess payPalSucess=new PayPalSucess();
		PayPalResult payPalResult=payPalSucess.getPayPal(request, payPalService.getPayPalConfig());
		System.out.println("Order");
		
		System.out.println(payPalResult.getFirst_name());
		
		System.out.println(payPalResult.getLast_name());
		
		return "cart/success";
	}
	
}
