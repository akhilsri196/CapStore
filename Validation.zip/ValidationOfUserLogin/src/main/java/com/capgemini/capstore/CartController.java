package com.capgemini.capstore;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;



@Controller
@RequestMapping("controller")
public class CartController {
	

	@RequestMapping(method = RequestMethod.GET,value="login")
	public String login(ModelMap modelMap ,/* HttpSession session,*/HttpServletRequest request) {
		return "cart/login";
	}
	@RequestMapping(method = RequestMethod.POST,value="validateUser")
	public String validate(@RequestParam(value="mobileNo") String mobileNo,@RequestParam(value="password") String password) {
		
		System.out.println(mobileNo);
		System.out.println(password);
		
		
		return "cart/success";
	}
	
}
