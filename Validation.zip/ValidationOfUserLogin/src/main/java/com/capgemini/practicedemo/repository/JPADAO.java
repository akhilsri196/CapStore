package com.capgemini.practicedemo.repository;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository
@Transactional
public class JPADAO implements IUserDAO{
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public String validateUser(String email) {
		// TODO Auto-generated method stub
		
		Query query =entityManager.createQuery("select u from Merchant u where ");
		
		return "";
	}
	
	

}
