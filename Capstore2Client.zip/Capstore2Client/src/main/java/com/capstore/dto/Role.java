package com.capstore.dto;

public enum Role {
	Customer,Admin,Merchant
}
